<ul id="MenuBar2" class="MenuBarVertical">
    <li><a href="index.php">Home</a>      </li>
    <li><a href="inbox.php">Messages</a>
      <ul>
        <li><a href="compose2.php">Compose</a> </li>
        <li><a href="inbox.php">Inbox</a></li>
        <li><a href="outbox.php">Sent</a></li>
      </ul>
    </li>
    <li><a href="payments.php">Payments</a></li>
    <li><a href="../logout.php">Logout</a></li>

  </ul>