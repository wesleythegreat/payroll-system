<?php
//mysqli_connect("localhost", "root", "") or die(mysql_error());
//mysql_select_db("newpayroll") or die(mysql_error());
    $host = "localhost"; // Host name
	$username = "root"; // Mysql username
	$password = null; // Mysql password
	$db_name = "newpayroll"; // Database name
	$tbl_name = "admin"; // Table name

	// Connect to server and select databse.
	$conn = mysqli_connect("$host", "$username", "$password" , "$db_name")or die("cannot connect");
?>